/*

Name: Jacob Saldana

Course: COSC-1436 with Dr. Tyson McMillan, Dr. T

IDE used: visual studio code/ replit.com

Summary: This program accepts input from the user until -1 is entered. For each input, it calculates and outputs the square of the number, the division of the number by itself, (n+3)/5, and [(n+3)/5 + (n+7)/2]. It also counts the number of iterations and outputs it after program termination.

Tested Values:
- For the input value 0, the program ran perfectly and presented square of the number 0, division by 0 is undefined, and gave me calculations of 0.6 and 4.1
- For the input value 'j', the program completely broke and did an infinite loop, stopping the program was even impossible and forced me to restart the program.

*/

#include <iostream>
using namespace std;

int main() 
{
    double n;
    int counter = 0; // Initialize counter to 0


   do{ // Loop until user enters -1
        cout << "Enter a number (-1 to exit): ";
        cin >> n;

        if (n != -1) // Check if input is not -1
        {

            cout << "You entered: " << n << endl; // Output the number entered 
            cout << "Square of the number: " << n * n << endl; // Calculate and output n*n 

            if (n != 0) // Check if n is not 0 to avoid division by zero
            {
                cout << "Division of the number by itself: " << n / n << endl; // Calculate and output n/n
            } 
            else 
            {
                cout << "Division by zero is undefined." << endl; // Handle division by zero
            }

            cout << "(n+3)/5: " << (n + 3) / 5 << endl; // Output (n+3)/5
            cout << "[(n+3)/5 + (n+7)/2]: " << ((n + 3) / 5) + ((n + 7) / 2) << endl; // Output [(n+3)/5 + (n+7)/2]
            counter++; // Increment counter

        }

      } while (n != -1);

    cout << "Number of iterations: " << counter << endl; // Output the value of the counter

    return 0;
}